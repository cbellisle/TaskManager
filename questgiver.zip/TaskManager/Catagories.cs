﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;


namespace TaskManager
{
    public partial class Catagories : Form
    {
        private string CurrentUser;
        private int userTasks;


        private List<String> catagories = new List<string>();
        private List<Color> colors = new List<Color>();

        public Catagories()
        {
            InitializeComponent();
        }
        public Catagories(string user, int tasks)
        {
            InitializeComponent();
            CurrentUser = user;
            userTasks = tasks;
        }

        private void Catagories_Load(object sender, EventArgs e)
        {
            this.FormBorderStyle = FormBorderStyle.FixedSingle;

            string path = $"C:/Users/1259809181117005/source/repos/TaskManager/users/{CurrentUser}/catagories.txt";

            if (File.Exists(path))
            {
                int i = 0;
                StreamReader read = new StreamReader(path);
                while (!read.EndOfStream)
                {
                    catagories.Add(read.ReadLine());
                    int color;
                    Int32.TryParse(read.ReadLine(), out color);
                    colors.Add(Color.FromArgb(color));
                    catagoryBox.Items.Add(catagories[i]);
                    i++;
                }
                read.Close();
            }

        }
        private void saveCatagories()
        {
            string path = $"C:/Users/1259809181117005/source/repos/TaskManager/users/{CurrentUser}/catagories.txt";
            StreamWriter write = new StreamWriter(path);
            for (int i = 0; i < colors.Count; i++)
            {
                write.WriteLine(catagories[i]);
                write.WriteLine(colors[i].ToArgb());
            }
            write.Close();
            
        }
        private void catagoryBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            //catagoryBox.Anchor;
            if(catagoryBox.SelectedItem != null)
            {
                catagorytextbox.Text = catagoryBox.SelectedItem.ToString();
                int item = catagories.IndexOf(catagorytextbox.Text);
                colorButton.BackColor = colors[item];
                removeButton.Enabled = true;
            }
                
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveCatagories();
            Hide();
            TaskPage page = new TaskPage(CurrentUser, userTasks, catagories, colors);
            page.Show();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            if(catagorytextbox.Text.Length > 0)
            {
                catagoryBox.Items.Add(catagorytextbox.Text);

                catagories.Add(catagorytextbox.Text);
                colors.Add(colorButton.BackColor);
                catagorytextbox.Clear();
                colorButton.BackColor = Color.White;
                MessageBox.Show("Catagory added successfully!");

            }
        }
                

        private void colorButton_Click(object sender, EventArgs e)
        {
            ColorDialog color = new ColorDialog();
            if  (color.ShowDialog() == DialogResult.OK)
            {
                colorButton.BackColor = color.Color;
                
            }    
        }

        private void removeButton_Click(object sender, EventArgs e)
        {
            catagories.Remove(catagoryBox.SelectedItem.ToString());
            colors.Remove(colors[catagoryBox.SelectedIndex]);
            catagoryBox.Items.Remove(catagoryBox.SelectedItem);
            catagoryBox.Invalidate();
            catagorytextbox.Clear();
            colorButton.BackColor = Color.White;
            //remove item from list :)
        }
    }
}
